import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class TurtleMoveNode(Node):
    def __init__(self):
        super().__init__('turtle_move_node')
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        timer_period = 0.5  # saniye
        self.timer = self.create_timer(timer_period, self.timer_callback)

    def timer_callback(self):
        msg = Twist()
        msg.linear.x = 2.0  # İleri hız
        msg.angular.z = 1.0 # Dönüş (daire çizer)
        self.publisher_.publish(msg)
        self.get_logger().info('Kaplumbağa hareket ediyor...')

def main(args=None):
    rclpy.init(args=args)
    turtle_move_node = TurtleMoveNode()
    rclpy.spin(turtle_move_node)
    turtle_move_node.destroy_node()
    rclpy.shutdown()
